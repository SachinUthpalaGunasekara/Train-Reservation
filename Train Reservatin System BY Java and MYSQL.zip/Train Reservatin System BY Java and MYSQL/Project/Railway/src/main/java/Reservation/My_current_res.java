
package Reservation;

public class My_current_res {

/*inisializing variables*/
	int Rid;  
	String Rname; 
	String Remail; 
	String Rphone; 
	String Rpax; 
	String Rfrom;
	String Rto;
	
	/*creating getters and setters*/
	public int getRid() {
		return Rid;
	}
	public void setRid(int rid) {
		Rid = rid;
	}
	public String getRname() {
		return Rname;
	}
	public void setRname(String rname) {
		Rname = rname;
	}
	public String getRemail() {
		return Remail;
	}
	public void setRemail(String remail) {
		Remail = remail;
	}
	public String getRphone() {
		return Rphone;
	}
	public void setRphone(String rphone) {
		Rphone = rphone;
	}
	public String getRpax() {
		return Rpax;
	}
	public void setRpax(String rpax) {
		Rpax = rpax;
	}
	public String getRfrom() {
		return Rfrom;
	}
	public void setRfrom(String rfrom) {
		Rfrom = rfrom;
	}
	public String getRto() {
		return Rto;
	}
	public void setRto(String rto) {
		Rto = rto;
	}
	
	
}
