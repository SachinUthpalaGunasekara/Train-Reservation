package Updateusers;

public class Current_users {
	
	int udi;
	String uname;
	String upassword;
	String uemail;
	String uPnum;
	public int getUdi() {
		return udi;
	}
	public void setUdi(int udi) {  //encapsulation
		this.udi = udi;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpassword() {
		return upassword;
	}
	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getuPnum() {
		return uPnum;
	}
	public void setuPnum(String uPnum) {
		this.uPnum = uPnum;
	}
	
}
